#include <stdint.h>

void adc_init(void);
uint16_t adc_result();
